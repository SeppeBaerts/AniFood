﻿using AutoMapper;
using ExampleWebApi.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Infrastructure
{
    public class UserRepository
    {
        ExampleDbContext _context;
        IMapper _mapper;

        public UserRepository(ExampleDbContext context, IMapper mapper)
        {
            _mapper = mapper;
            _context = context;
        }
        public UserDto GetUserDto(Guid id)
        {
            var user = _context.Users.Include(u => u.Families).Where(u => u.Id == id).FirstOrDefault();
            var userDto = _mapper.Map<UserDto>(user);
            return userDto;
        }
        public User GetUser(Guid id)
        {
            var user = _context.Users.Include(u => u.Families).Where(u => u.Id == id).FirstOrDefault();
            return user;
        }
        public List<UserDto> GetAllUsers()
        {
            return _context.Users.Include(u => u.Families).Select(u => new UserDto(u)).ToList();
        }
        public List<MinUserInfo> GetMinUserFromFamily(Guid famId)
        {
            var family = _context.Families.Include(f => f.Users).Where(f => f.FamilyId == famId).FirstOrDefault();
            var userList = family.Users;
            var users = userList?.Select(u => new MinUserInfo { IsFamilyHead= family.FamilyHeadId == u.Id, Id = u.Id, NickName = u.NickName }).ToList();
            return users ?? throw new ArgumentOutOfRangeException();
        }
        public bool ChangeUserInfo(UserDto user)
        {
            try
            {
                var oldUser = _context.Users.Include(u => u.Families).Where(u => u.Id == user.Id).FirstOrDefault();
                oldUser.NickName = user.NickName;
                oldUser.FirstName = user.FirstName;
                oldUser.LastName = user.LastName;
                _context.Users.Update(oldUser);
                _context.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }

    }
}
