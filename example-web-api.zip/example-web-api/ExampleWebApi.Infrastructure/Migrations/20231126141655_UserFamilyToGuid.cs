﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExampleWebApi.Infrastructure.Migrations
{
    public partial class UserFamilyToGuid : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Animals_Families_MainFamilyId",
                table: "Animals");

            migrationBuilder.DropForeignKey(
                name: "FK_FamilyUser_Families_FamiliesId",
                table: "FamilyUser");

            migrationBuilder.DropForeignKey(
                name: "FK_Foods_Families_ParentFamilyId",
                table: "Foods");

            migrationBuilder.RenameColumn(
                name: "ParentFamilyId",
                table: "Foods",
                newName: "ParentFamilyFamilyId");

            migrationBuilder.RenameIndex(
                name: "IX_Foods_ParentFamilyId",
                table: "Foods",
                newName: "IX_Foods_ParentFamilyFamilyId");

            migrationBuilder.RenameColumn(
                name: "FamiliesId",
                table: "FamilyUser",
                newName: "FamiliesFamilyId");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Families",
                newName: "FamilyId");

            migrationBuilder.RenameColumn(
                name: "MainFamilyId",
                table: "Animals",
                newName: "MainFamilyFamilyId");

            migrationBuilder.RenameIndex(
                name: "IX_Animals_MainFamilyId",
                table: "Animals",
                newName: "IX_Animals_MainFamilyFamilyId");

            migrationBuilder.AddForeignKey(
                name: "FK_Animals_Families_MainFamilyFamilyId",
                table: "Animals",
                column: "MainFamilyFamilyId",
                principalTable: "Families",
                principalColumn: "FamilyId");

            migrationBuilder.AddForeignKey(
                name: "FK_FamilyUser_Families_FamiliesFamilyId",
                table: "FamilyUser",
                column: "FamiliesFamilyId",
                principalTable: "Families",
                principalColumn: "FamilyId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Foods_Families_ParentFamilyFamilyId",
                table: "Foods",
                column: "ParentFamilyFamilyId",
                principalTable: "Families",
                principalColumn: "FamilyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Animals_Families_MainFamilyFamilyId",
                table: "Animals");

            migrationBuilder.DropForeignKey(
                name: "FK_FamilyUser_Families_FamiliesFamilyId",
                table: "FamilyUser");

            migrationBuilder.DropForeignKey(
                name: "FK_Foods_Families_ParentFamilyFamilyId",
                table: "Foods");

            migrationBuilder.RenameColumn(
                name: "ParentFamilyFamilyId",
                table: "Foods",
                newName: "ParentFamilyId");

            migrationBuilder.RenameIndex(
                name: "IX_Foods_ParentFamilyFamilyId",
                table: "Foods",
                newName: "IX_Foods_ParentFamilyId");

            migrationBuilder.RenameColumn(
                name: "FamiliesFamilyId",
                table: "FamilyUser",
                newName: "FamiliesId");

            migrationBuilder.RenameColumn(
                name: "FamilyId",
                table: "Families",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "MainFamilyFamilyId",
                table: "Animals",
                newName: "MainFamilyId");

            migrationBuilder.RenameIndex(
                name: "IX_Animals_MainFamilyFamilyId",
                table: "Animals",
                newName: "IX_Animals_MainFamilyId");

            migrationBuilder.AddForeignKey(
                name: "FK_Animals_Families_MainFamilyId",
                table: "Animals",
                column: "MainFamilyId",
                principalTable: "Families",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_FamilyUser_Families_FamiliesId",
                table: "FamilyUser",
                column: "FamiliesId",
                principalTable: "Families",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Foods_Families_ParentFamilyId",
                table: "Foods",
                column: "ParentFamilyId",
                principalTable: "Families",
                principalColumn: "Id");
        }
    }
}
