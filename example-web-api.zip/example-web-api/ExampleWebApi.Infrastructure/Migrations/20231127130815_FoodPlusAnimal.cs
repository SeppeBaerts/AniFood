﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExampleWebApi.Infrastructure.Migrations
{
    public partial class FoodPlusAnimal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CurrentCapacity",
                table: "Foods",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FoodAmountPerDay",
                table: "Animals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FoodTimesPerDay",
                table: "Animals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TimesFed",
                table: "Animals",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CurrentCapacity",
                table: "Foods");

            migrationBuilder.DropColumn(
                name: "FoodAmountPerDay",
                table: "Animals");

            migrationBuilder.DropColumn(
                name: "FoodTimesPerDay",
                table: "Animals");

            migrationBuilder.DropColumn(
                name: "TimesFed",
                table: "Animals");
        }
    }
}
