﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("ExampleWebApi.Api")]