﻿using AutoMapper;
using ExampleWebApi.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;


namespace ExampleWebApi.Infrastructure
{
    public class FamilyRepository
    {
        private readonly ExampleDbContext _context;
        IMapper _mapper;
        public FamilyRepository(ExampleDbContext context, IMapper mapper)
        {
            _mapper = mapper;
            _context = context;
        }
        public List<FamilyGuidModel> GetFamilyGuid(User user)
        {
            var families = GetFullFamilies();
            var family = families.Where(f => f.Users.Contains(user)).Select(f => _mapper.Map<FamilyGuidModel>(f)).ToList();
            return family;
        }
        public List<FamilyGuidModel> GetFamilyGuid(Guid userId)
        {
            var user = _context.Users
                .Where(u => u.Id == userId)
                .FirstOrDefault() ?? throw new ArgumentNullException(nameof(userId), "User not found.");
            return GetFamilyGuid(user);
        }
        public FamilyGuidModel GetFamilyByGuid(Guid familyId)
        {
            var family = GetFullFamily(familyId);
            return _mapper.Map<FamilyGuidModel>(family);
        }
        public Family CreateFamily(Family family)
        {
            _context.Families.Add(family);
            _context.SaveChanges();
            return family;
        }
        public bool RemoveFamily(Family family)
        {
            try
            {
                foreach(var animal in family.Animals)
                {
                    _context.Animals.Remove(animal);
                }
                foreach(var food in family.Foods)
                {
                    _context.Foods.Remove(food);
                }
                _context.Families.Remove(family);
                _context.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }
        public bool RemoveFamily(Guid familyId)
        {
            return RemoveFamily(GetCompactFamily(familyId));
        }
        public bool RemoveFromFamily(Guid familyId, Guid userid)
        {
            try
            {
                Family fam = GetFullFamily(familyId) ?? throw new KeyNotFoundException();
                User user = fam.Users.Where(u => u.Id == userid).FirstOrDefault() ?? throw new KeyNotFoundException();
                return RemoveFromFamily(fam, user);
            }
            catch
            {
                return false;
            }
        }
        private bool RemoveFromFamily(Family fam, User user)
        {
            try
            {
                fam.Users.Remove(user);
                _context.Families.Update(fam);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool AddUserToFamily(User user, Guid familyId)
        {
            var family = GetFullFamily(familyId);
            if (family == null || user == null || family.Users == null || family.Users.Contains(user))
                return false;
            family.Users.Add(user);

            _context.Families.Update(family);

            if (_context.SaveChanges() == 0)
            {
                throw new Exception("No changes were made.");
            }
            return true;
        }
        public Family? GetCompactFamily(Guid familyId)
        {
            return _context.Families
                .Where(f => f.FamilyId == familyId)
                .FirstOrDefault() ?? null;
        }
        public Family? GetFullFamily(Guid familyId)
        {
            var family = GetFullFamilies()
                .Where(f => f.FamilyId == familyId)
                .FirstOrDefault() ??
                throw new ArgumentNullException(
                    nameof(familyId), "Family not found.");
            return family;
        }
        private List<Family> GetFullFamilies()
        {
            var families = _context.Families
                .Include(f => f.Animals)
                .Include(f => f.Foods)
                .Include(f => f.Users)
                .Include(f => f.FamilyCode)
                .ToList();
            return families;
        }
        private List<FamilyGuidModel> GetGuidFamilies()
        {
            var families = _context.Families
                .Include(f => f.Animals)
                .Include(f => f.Foods)
                .Include(f => f.Users)
                .Include(f => f.FamilyCode)
                .ToList();
            return _mapper.Map<List<FamilyGuidModel>>(families);
        }
        public List<FamilyGuidModel> GetAllFamilies()
        {
            return GetGuidFamilies();
        }
        public List<UserDto> GetUsersFromFamily(Guid id)
        {
            var family = _context.Families
                .Where(f => f.FamilyId == id)
                .Include(f => f.Users)
                .FirstOrDefault();
            var usrDto = _mapper.Map<List<UserDto>>(family.Users ?? throw new ArgumentOutOfRangeException(nameof(id), "no users are found in this family"));
            return usrDto;
        }
        public bool AddUserToFamily(User user, string familyCode)
        {
            try
            {
                return AddUserToFamily(user, GetFamId(familyCode));
            }
            catch
            {
                return false;
            }
        }
        public string GetCodeByFamilyId(Guid familyId, bool overwrite = false)
        {
            var famcode = _context.FamilyCodes.Where(f => f.FamilyId == familyId).FirstOrDefault() ?? new FamilyCode();
            if (overwrite || famcode?.CodeId == null)
            {
                if (famcode.CodeId != null)
                    _context.FamilyCodes.Remove(famcode);
                string code = CreateCode();
                _context.FamilyCodes.Add(new FamilyCode { CodeId = code, FamilyId = familyId });
                _context.SaveChanges();
                return code;
            }
            return famcode.CodeId;
        }
        public Family? GetFamilyByCode(string familyCode)
        {
            var famcode = _context.FamilyCodes.Where(f => f.CodeId == familyCode).FirstOrDefault();
            if (famcode != null)
            {
                var family = _context.Families.Where(f => f.FamilyId == famcode.FamilyId).FirstOrDefault();
                return family;
            }
            throw new ArgumentNullException(nameof(familyCode), "Code not exsistent.");
        }
        public Guid GetFamId(string familyCode)
        {
            var fam = _context.FamilyCodes.Where(f => f.CodeId == familyCode).FirstOrDefault();
            try
            {
                return fam.FamilyId;
            }
            catch
            {
                throw new ArgumentNullException(nameof(familyCode), "Code not exsistent.");
            }
        }
        readonly char[] upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
        readonly char[] numbers = "1234567890".ToCharArray();
        /// <summary>
        /// Creates a new code for the FamilyCode table.
        /// </summary>
        /// <returns>A new code that doesn't exist in the family code table</returns>
        private string CreateCode()
        {
            Random r = new();
            int length = 6;
            StringBuilder codeBuilder = new StringBuilder();
            for (int i = 0; i < length; i++)
            {
                if (r.Next(0, 2) == 0)
                    codeBuilder.Append(upper[r.Next(0, upper.Length)]);
                else
                    codeBuilder.Append(numbers[r.Next(0, numbers.Length)]);
            }
            if (_context.FamilyCodes.Any(c => c.CodeId == codeBuilder.ToString()))
                return CreateCode();
            else
                return codeBuilder.ToString();
        }
    }
}
