﻿using AutoMapper;
using ExampleWebApi.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Infrastructure
{
    public class FoodRepository
    {
        ExampleDbContext _context;
        IMapper _mapper;
        public FoodRepository(ExampleDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public List<FoodGuidModel> GetFoodsFromFamily(Guid familyId)
        {
            var foods = GetGuidFoods().Where(f => f.ParentFamily == familyId).ToList();
            return foods;
        }
        public Food CreateFood(Food food)
        {
            _context.Foods.Add(food);
            _context.SaveChanges();
            return food;
        }
        /// <summary>
        /// This function does not get the foods that are full
        /// </summary>
        /// <returns> A list of foods that have includes.</returns>
        private List<Food> GetFullFoods()
        {
            return _context.Foods
                .Include(f => f.ParentFamily)
                .Include(f => f.Animals).ToList();
        }
        public Food GetFullFood(Guid id)
        {
            var food = GetFullFoods();
            return food.Where(f => f.Id == id).FirstOrDefault();
        }
        public bool AddAnimal(Guid foodId, Guid animalId)
        {
            if (foodId != Guid.Empty && animalId != Guid.Empty)
            {
                try
                {
                    var food = GetFullFood(foodId);
                    var animal = _context.Animals.Where(a => a.Id == animalId).FirstOrDefault() ??
                        throw new ArgumentNullException(nameof(animalId), "Animal not found");
                    if (food.Animals.Contains(animal))
                        return false;
                    food.Animals.Add(animal);
                    _context.Foods.Update(food);
                    if (_context.SaveChanges() > 0)
                        return true;
                }
                catch
                {
                    throw;
                }
            }
            return false;
        }
        public FoodGuidModel GetGuidFood(Guid id)
        {
            var food = GetGuidFoods();
            return food.Where(f => f.Id == id).FirstOrDefault() ?? 
                throw new ArgumentOutOfRangeException(nameof(id), "No food found with that id") ;
        }
        public List<FoodGuidModel> GetGuidFoods()
        {
            try
            {
            var food = GetFullFoods();
            var guidFood = _mapper.Map<List<FoodGuidModel>>(food);
                return guidFood;
            }
            catch
            {
                throw;
            }
        }
        public int RefillFoodBag(Guid foodId)
        {
            var food = GetFullFood(foodId);
            if (food.NewBags > 0)
                food.NewBags--;
            food.Refill();
            _context.Foods.Update(food);
            _context.SaveChanges();
            return food.CurrentCapacity;
        }
        public Food DeleteFood(Guid foodId)
        {
            var food = GetFullFood(foodId);
            _context.Foods.Remove(food);
            _context.SaveChanges();
            return food;
        }
        public async Task<int> AddFoodBags(Guid foodId, int amount)
        {
            var food = GetFullFood(foodId);
            food.NewBags = amount;
            if(food.NewBags < 0)
            {
                food.NewBags = 0;
            }
            _context.Foods.Update(food);
            await _context.SaveChangesAsync();
            return food.NewBags;
        }
    }
}
