﻿using AutoMapper;
using ExampleWebApi.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Infrastructure
{
    public class AnimalRepository
    {
        private readonly ExampleDbContext _context;
        private readonly IMapper _mapper;
        public AnimalRepository(ExampleDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public async Task<List<Animal>> GetAllAnimals()
        {
            return await _context.Animals.ToListAsync();
        }
        public Animal CreateAnimalAsync(Animal animal)
        {
            _context.Animals.Add(animal);
            _context.SaveChanges();
            return animal;
        }
        public List<AnimalModel> GetAnimalsFromFamily(Guid familyId)
        {
            var animals = _context.Animals
                .Include(a => a.Food)
                .Include(a => a.MainFamily)
                .Where(a => a.MainFamily.FamilyId == familyId).ToList();
            foreach(Animal ani in animals)
            {
                if(ani.LastTimeFed == null)
                {
                    ani.LastTimeFed = DateTime.Now;
                    ani.TimesFed = 0;
                }
                else if(ani.LastTimeFed?.Date != DateTime.Now.Date)
                {
                    ani.TimesFed = 0;
                }
            }
            _context.Animals.UpdateRange(animals);
            _context.SaveChanges();
            return _mapper.Map<List<AnimalModel>>(animals);
        }
        
        public int FeedAnimal(Guid animId)
        {
            try
            {
                var animal = _context.Animals.Include(f => f.Food).Where(a => a.Id == animId).FirstOrDefault();
                if (animal == null)
                {
                    return -1;
                }
                animal.FeedAnimal();
                _context.Animals.Update(animal);
                if(animal.Food != null)
                    _context.Foods.Update(animal.Food);

                _context.SaveChanges();
                if(animal.Food?.CurrentCapacity < 0)
                {
                    animal.Food.CurrentCapacity = 0;
                    return 0;
                }
                return animal.Food == null? 0 : animal.Food.CurrentCapacity;
            }
            catch (Exception ex)
            {
                return -1;
                throw;
            }
        }
        public async Task RemoveAnimal(Guid animalId)
        {
            var animals = await GetAllAnimals();
            var animal = animals.Where(a => a.Id == animalId).FirstOrDefault();
            var imagePath = Path.Combine("Pictures", animal.ImageUri);
            if(animal.ImageUri != "unknown.jpg" && File.Exists(imagePath))
                File.Delete(imagePath);
            var changingAnimal = _context.Animals.Remove(animal);
            int changes = _context.SaveChanges();
            if (changes == 0)
                throw new Exception("something went wrong");
        }
        public async Task<bool> ChangeAnimalInfo(AnimalModel animal)
        {
            Animal ani = _context.Animals
                .Include(a => a.Food)
                .Include(a => a.MainFamily)
                .Where(a => a.Id == animal.Id).FirstOrDefault() ?? new Animal();

            if(ani.ImageUri != animal.ImageUri)
            {
                File.Delete(Path.Combine("Pictures", ani.ImageUri));
            }

            ani.Name = animal.Name;
            ani.ImageUri = animal.ImageUri;
            ani.FoodAmountPerDay = animal.FoodAmountPerDay;
            ani.FoodTimesPerDay = animal.FoodTimesPerDay;
            ani.Birthday = animal.Birthday;
            ani.Notes = animal.Notes;
            ani.Breed = animal.Breed;
            _context.Update(ani);
            _context.SaveChanges();
            return true;
        }
    }
}
