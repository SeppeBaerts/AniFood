﻿using ExampleWebApi.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Infrastructure
{
    public class ActorRepository
    {
        private readonly ExampleDbContext _context;
        public ActorRepository(ExampleDbContext context)
        {
            _context = context;
        }
        public async Task<List<Actor>> GetAllActors()
        {
            return await _context.Actors.ToListAsync();
        }
    }
}
