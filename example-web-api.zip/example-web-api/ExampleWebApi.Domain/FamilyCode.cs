﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Domain
{
    public class FamilyCode
    {
        [Key]
        public string CodeId { get; set; }
        public Guid FamilyId { get; set; }
    }
}
