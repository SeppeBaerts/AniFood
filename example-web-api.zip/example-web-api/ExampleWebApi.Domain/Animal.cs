﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Domain
{
    public class Animal
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public Food? Food { get; set; }
        public Family? MainFamily { get; set; }
        public string ImageUri { get; set; }
        public int FoodAmountPerDay { get; set; }
        public int FoodTimesPerDay { get; set; }
        public int TimesFed { get; set; }
        public DateTime? LastTimeFed { get; set; }
        public DateTime? Birthday { get; set; }
        public string? Notes { get; set; }
        public string? Breed { get; set; }

        /// <summary>
        /// this method will feed the animal and decrease the current capacity of the food bag
        /// IT WILL NOT UPDATE THE DATABASE
        /// </summary>
        /// <param name="amount"></param>
        public void FeedAnimal()
        {
            if (LastTimeFed == null || LastTimeFed?.Date != DateTime.Now.Date)
            {
                TimesFed = 0;
            }

            if (Food != null)
            {
                Food.CurrentCapacity -= (int)Math.Round((decimal)FoodAmountPerDay / FoodTimesPerDay);
            }
            LastTimeFed = DateTime.Now;
            TimesFed++;
        }


    }
    public class AnimalModel
    {
        public Guid? Id { get; set; }
        public string Name { get; set; }
        public string? ImageUri { get; set; }
        public Guid? FoodId { get; set; }
        public Guid? MainFamilyId { get; set; }
        public int FoodAmountPerDay { get; set; }
        public int FoodTimesPerDay { get; set; }
        public int TimesFed { get; set; }
        public DateTime LastTimeFed { get; set; }
        public DateTime? Birthday { get; set; }
        public string? Notes { get; set; }
        public string? Breed { get; set; }
        private class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Animal, AnimalModel>()
                    .ForMember(dest => dest.FoodId, opt => opt.MapFrom(src => src.Food.Id))
                    .ForMember(dest => dest.MainFamilyId, opt => opt.MapFrom(src => src.MainFamily.FamilyId));
            }
        }
    }
}
