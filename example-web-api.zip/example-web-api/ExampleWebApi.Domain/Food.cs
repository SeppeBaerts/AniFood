﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Domain
{

    public class Food
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Animal>? Animals { get; set; }
        public Family? ParentFamily { get; set; }
        public string ImageUri { get; set; }
        public FoodType Type { get; set; }
        /// <summary>
        /// Capacity of the food bag (ex. 2500g)
        /// </summary>
        public int Capacity { get; set; }
        /// <summary>
        /// Current capacity of the food bag (ex. 1000g)
        /// </summary>
        public int CurrentCapacity { get; set; }
        /// <summary>
        /// If the user has bought a new bag but the current bag is not yet empty,
        /// this property will refill the current bag with the new bag when the current capacity > 0
        /// </summary>
        public int NewBags { get; set; }

        private int TotalUseGrams
        {
            get
            {
                int totalUseGrams = 0;
                foreach (Animal ani in Animals)
                {
                    totalUseGrams += ani.FoodAmountPerDay;
                }
                return totalUseGrams;
            }
        }
        internal int DaysLeft
        {
            get
            {
                if (Type == FoodType.Liquid)
                    return 0;
                int daysLeft = (int)Math.Round((decimal)CurrentCapacity / TotalUseGrams);
                if (daysLeft < 0)
                    return 0;
                return daysLeft;
            }
        }
        internal bool HasFood => CurrentCapacity > 0;
        public void Refill()
        {
            CurrentCapacity = Capacity;
        }
    }
    public class FoodGuidModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Guid>? Animals { get; set; }
        public Guid? ParentFamily { get; set; }
        public string ImageUri { get; set; }
        public FoodType Type { get; set; }
        /// <summary>
        /// Capacity of the food bag (ex. 2500g)
        /// </summary>
        public int Capacity { get; set; }
        /// <summary>
        /// Current capacity of the food bag (ex. 1000g)
        /// </summary>
        public int CurrentCapacity { get; set; }
        public int NewBags { get; set; }

        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Food, FoodGuidModel>()
                    .ForMember(dest => dest.Animals, opt => opt.MapFrom(src => src.Animals.Select(f => f.Id)))
                    .ForMember(dest => dest.ParentFamily, opt => opt.MapFrom(src => src.ParentFamily.FamilyId));
            }
        }
    }

    public enum FoodType
    {
        Bag,
        Liquid
    }
}
