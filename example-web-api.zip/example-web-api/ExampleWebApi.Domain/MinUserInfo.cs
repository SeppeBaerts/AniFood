﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Domain
{
    public class MinUserInfo
    {
        public Guid Id { get; set; }
        public string NickName { get; set; }
        public bool IsFamilyHead { get; set; }
    }
}
