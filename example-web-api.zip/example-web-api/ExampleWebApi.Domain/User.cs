﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Microsoft.AspNetCore.Identity;

namespace ExampleWebApi.Domain;

public class User : IdentityUser<Guid>
{
    [Required]
    public string NickName { get; set; }
    public List<Family>? Families { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
}
public class UserDto
{
    public Guid Id { get; set; }
    public string Email { get; set; }
    public string NickName { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public List<Guid> FamilyIds { get; set; } // Only store the family IDs, not the entire family objects
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDto>()
                .ForMember(dest => dest.FamilyIds, opt => opt.MapFrom(src => src.Families.Select(f => f.FamilyId)));
        }
    }
    public UserDto(User user)
    {
        Id = user.Id;
        Email = user.Email;
        NickName = user.NickName;
        FirstName = user.FirstName;
        LastName = user.LastName;
        FamilyIds = user.Families.Select(f => f.FamilyId).ToList();
    }
    public UserDto() { }
}