﻿using AutoMapper;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ExampleWebApi.Domain
{
    public class Family
    {
        public Guid FamilyId { get; set; }
        public string Name { get; set; }
        public List<Animal>? Animals { get; set; }
        public List<Food>? Foods { get; set; }
        public List<User>? Users { get; set; }
        public string? ImageUri { get; set; }
        public User? FamilyHead => Users?.Where(u => u.Id == FamilyHeadId).FirstOrDefault();
        public Guid FamilyHeadId { get; set; }
        public FamilyCode? FamilyCode { get; set; }
    }
    /// <summary>
    /// This will return the info of the object.
    /// </summary>
    public class FamilyInfoModel
    {
        public Guid FamilyId { get; set; }
        public string Name { get; set; }
        public Guid FamilyHead { get; set; }
        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Family, FamilyInfoModel>();
            }
        }
    }
    public class FamilyGuidModel
    {
        public Guid FamilyId { get; set; }
        public string Name { get; set; }
        public string? ImageUri { get; set; }
        public List<Guid> UserIds { get; set; }
        public List<Guid> FoodIds { get; set; }
        public List<Guid> AnimalIds { get; set; }
        public Guid FamilyHeadId { get; set; }
        public FamilyCode? FamilyCode { get; set; }
        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Family, FamilyGuidModel>()
                    .ForMember(dest => dest.UserIds, opt => opt.MapFrom(src => src.Users.Select(u => u.Id)))
                    .ForMember(dest => dest.FoodIds, opt => opt.MapFrom(src => src.Foods.Select(f => f.Id)))
                    .ForMember(dest => dest.AnimalIds, opt => opt.MapFrom(src => src.Animals.Select(f => f.Id)));
            }
        }
    }
    public class FullFamilyGuid
    {
        public Guid FamilyId { get; set; }
        public string Name { get; set; }
        public string? ImageUri { get; set; }
        public List<MinUserInfo> UserIds { get; set; }
        public List<Guid> FoodIds { get; set; }
        public List<Guid> AnimalIds { get; set; }
        public Guid FamilyHeadId { get; set; }
        public FamilyCode? FamilyCode { get; set; }
        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Family, FullFamilyGuid>()
                    .ForMember(dest => dest.UserIds, opt => opt.MapFrom(src => src.Users.Select(u => new MinUserInfo() { Id = u.Id, IsFamilyHead = src.FamilyHeadId == u.Id, NickName = u.NickName })))
                    .ForMember(dest => dest.FoodIds, opt => opt.MapFrom(src => src.Foods.Select(f => f.Id)))
                    .ForMember(dest => dest.AnimalIds, opt => opt.MapFrom(src => src.Animals.Select(f => f.Id)));
            }
        }
    }
}
