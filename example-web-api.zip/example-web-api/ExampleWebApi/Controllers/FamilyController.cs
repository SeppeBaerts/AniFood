﻿using AutoMapper;
using ExampleWebApi.Api.Models;
using ExampleWebApi.Domain;
using ExampleWebApi.Infrastructure;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;
using System.Text.Json.Serialization;

namespace ExampleWebApi.Api.Controllers
{
    [Route("api/Family")]
    public class FamilyController : ApiControllerBase
    {
        private readonly FamilyRepository _familyRepository;
        private readonly UserManager<User> _userManager;
        private readonly IMapper _mapper;
        public FamilyController(ExampleDbContext example, UserManager<User> userManager, IMapper mapper)
        {
            _familyRepository = new FamilyRepository(example, mapper);
            _userManager = userManager;
            _mapper = mapper;
        }
#if DEBUG
        //BELANGRIJK: VERWIJDER DIT NADIEN.
        [HttpGet("AllFamilies")]
        public IActionResult GetAll()
        {
            var families = _familyRepository.GetAllFamilies();
            return Ok(families);
        }
#endif
        [HttpGet()]
        public IActionResult MyFamilies()
        {
            return Ok(_familyRepository.GetFamilyGuid(UserId));
        }
        [HttpPost("Create")]
        public IActionResult CreateFamily([FromBody]FamilyModel model)
        {
            User currentUser = _userManager.Users.First(u => u.Id == UserId);
            if (currentUser != null)
            {
                List<User> users = new()
                {
                    currentUser
                };

                Family family = new Family
                {
                    Name = model.Name,
                    ImageUri = model.ImageUri ?? "none.jpg",
                    FamilyHeadId = currentUser.Id,
                    Users = users,
                };
                _familyRepository.CreateFamily(family);
                return Ok(family.FamilyId);
            }
            else
            {
                return Unauthorized();
            }
        }
        [HttpGet("GetUsers/{familyId}")]
        public IActionResult GetUsers(Guid familyId)
        {
            var users = _familyRepository.GetUsersFromFamily(familyId);
            var user = users.FirstOrDefault();
            return Ok(users);
        }
        [HttpDelete("Remove/{familyGuid}")]
        public IActionResult RemoveFamily(Guid familyGuid)
        {
            Family? family = _familyRepository.GetFullFamily(familyGuid);
            if (family == null)
                return NotFound();
            else if (family.FamilyHead != null && family.FamilyHead.Id != UserId)
                return Unauthorized();
            else
            {
                if (_familyRepository.RemoveFamily(family)) return Ok();
                else return BadRequest();
            }
        }
        [HttpGet("AddUser/{famcode}")]
        public IActionResult AddUserFamCode(string famcode)
        {
            User? user = _userManager.Users.Where(u => u.Id == UserId).FirstOrDefault();
            try
            {
                if (user == null)
                    return NotFound("User is not found");
                else if (_familyRepository.GetFamilyByCode(famcode) == null)
                    return NotFound("Family is not found");
            }
            catch (Exception ex)
            {
                return NotFound("family is not found");
            }
            try
            {
                if (_familyRepository.AddUserToFamily(user, famcode)) return Ok();
                else return BadRequest("Something went wrong trying to add the User.");
            }
            catch
            {
                return BadRequest("Something went wrong trying to add the User. It could be that this user already is a member of the family.");
            }
        }
        [HttpGet("GetCode/{familyId}")]
        public IActionResult GetFamilyCode(Guid familyId)
        {
            try
            {
                return Ok(_familyRepository.GetCodeByFamilyId(familyId));
            }
            catch
            {
                throw;
            }
        }
        [HttpGet("OverWriteCode/{familyId}")]
        public IActionResult ReplaceFamilyCode(Guid familyId)
        {
            try
            {
                return Ok(_familyRepository.GetCodeByFamilyId(familyId, true));
            }
            catch
            {
                throw;
            }
        }
        [HttpGet("GetGuidFamily/{familyId}")]
        public IActionResult GetGuidFamily(Guid familyId)
        {
            try
            {
                FamilyGuidModel model = _familyRepository.GetFamilyByGuid(familyId);
                if (model.UserIds.Contains(UserId))
                    return Ok(model);
                else
                    return Unauthorized();
            }
            catch(Exception ex)
            {
                return BadRequest(ex);
                throw;
            }
        }
        [HttpDelete("CloseFamily/{familyId}")]
        public IActionResult QuitFamily(Guid familyId)
        {
            try
            {
                _familyRepository.RemoveFromFamily(familyId, UserId);
                return Ok();
            }
            catch
            {
                return BadRequest("Something went wrong trying to remove the user from the family.");
            }
        }
        [HttpDelete("RemoveUser/{familyId}/{userId}")]
        public IActionResult RemoveUserFromFamily(Guid familyId, Guid userId)
        {
            try
            {
                bool hasRemoved = _familyRepository.RemoveFromFamily(familyId, userId);
                if (hasRemoved) return Ok();
                else return BadRequest("Something went wrong trying to remove the user from the family.");
            }
            catch
            {
                return BadRequest("Something went wrong trying to remove the user from the family.");
            }
        }
    }
}
