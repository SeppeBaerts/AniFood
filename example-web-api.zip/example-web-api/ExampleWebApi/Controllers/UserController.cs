﻿using AutoMapper;
using ExampleWebApi.Domain;
using ExampleWebApi.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;

namespace ExampleWebApi.Api.Controllers
{
    [Route("api/User")]
    public class UserController : ApiControllerBase
    {
        private readonly UserRepository _userRepository;
        private readonly UserManager<User> _userManager;
        private readonly IMapper _mapper;
        public UserController(ExampleDbContext example, UserManager<User> userManager, IMapper mapper)
        {
            _userRepository = new UserRepository(example, mapper);
            _userManager = userManager;
            _mapper = mapper;
        }

        [HttpGet("GetUsers")]
        public IActionResult GetUsers()
        {
            return Ok(_userRepository.GetAllUsers());
        }
        [HttpGet("GetUser")]
        public IActionResult GetUser()
        {
            try
            {
                return Ok(_userRepository.GetUserDto(UserId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
                throw;
            }
        }
        [HttpGet("GetFamUsers/{famId}")]
        public async Task<IActionResult> GetFamUsers(Guid famId)
        {
            try
            {
                return Ok(_userRepository.GetMinUserFromFamily(famId));
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpPut("ChangeUserInfo")]
        public IActionResult ChangeUser([FromBody] UserDto newUser)
        {
            try
            {
                if (_userRepository.ChangeUserInfo(newUser))
                    return Ok();
                else return BadRequest();
            }
            catch
            {
                return BadRequest();
            }
        }
        [HttpPost("UploadImage")]
        public async Task<IActionResult> UserImage(IFormFile file)
        {
            string filePath;
            string fileName;
            do
            {
                string randomName = Path.GetRandomFileName();
                fileName = randomName + "." + file.FileName.Split('.').Last();
                filePath = Path.Combine("Pictures", "UserPictures", fileName);
            } while (System.IO.File.Exists(filePath));

            using (var stream = System.IO.File.Create(filePath))
            {
                await file.CopyToAsync(stream);
            }

            return Ok(fileName);
        }
        [AllowAnonymous]
        [HttpGet("GetImage/{fileName}")]
        public async Task<IActionResult> GetImage(string fileName)
        {
            try
            {
                var filePath = Path.Combine("Pictures", "UserPictures", fileName);
                var image = System.IO.File.OpenRead(filePath);
                return File(image, $"image/jpeg");
            }
            catch
            {
                var image = System.IO.File.OpenRead("Pictures\\unknown.jpg");
                return File(image, "image/jpeg");
            }
        }
    }
}
