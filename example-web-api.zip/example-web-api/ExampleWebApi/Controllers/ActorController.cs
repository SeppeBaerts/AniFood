﻿using ExampleWebApi.Infrastructure;

namespace ExampleWebApi.Api.Controllers
{
    public class ActorController
    {
        private readonly ActorRepository _actorRepository;
        public ActorController(ActorRepository actorRepository)
        {
            _actorRepository = actorRepository;
        }
    }
}
