﻿using AutoMapper;
using ExampleWebApi.Api.Models;
using ExampleWebApi.Domain;
using ExampleWebApi.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace ExampleWebApi.Api.Controllers
{
    [Route("api/Food")]
    public class FoodController : ApiControllerBase
    {
        private readonly FoodRepository _foodRepository;
        private readonly FamilyRepository _familyRepository;
        private readonly IMapper _mapper;
        public FoodController(ExampleDbContext example, IMapper mapper)
        {
            _foodRepository = new FoodRepository(example, mapper);
            _familyRepository = new FamilyRepository(example, mapper);
            _mapper = mapper;
        }
        [HttpPost("Create")]
        public IActionResult CreateFood([FromBody]FoodModel food)
        {
            if (food.ParentFamily == Guid.Empty)
                return BadRequest("ParentFamily is required");

            Food realFood = new()
            {
                Name = food.Name,
                ImageUri = food.ImageUri ?? "unknown.png",
                ParentFamily = _familyRepository.GetCompactFamily(food.ParentFamily),
                Capacity = food.Capacity,
                CurrentCapacity = food.CurrentCapacity ?? food.Capacity,
                NewBags = 0,
            };
            _foodRepository.CreateFood(realFood);
            return Ok(realFood.Id);
        }
        [HttpGet("AddToAnimal/{animalId}/{foodId}")]
        public IActionResult AddToAnimal(Guid animalId, Guid foodId)
        {
            try
            {
                if (_foodRepository.AddAnimal(foodId, animalId))
                    return Ok();
                return BadRequest("Something went wrong trying to add the Food.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        [HttpGet("getFoods")]
        public IActionResult GetAllFoods()
        {
            try
            {
                return Ok(_foodRepository.GetGuidFoods());
            }
            catch (Exception ex)
            {
                return BadRequest($"Something went wrong: {ex.Message}");
            }
        }
        [HttpPost("Refill/{foodId}")]
        public IActionResult RefillFood(Guid foodId)
        {
            try
            {
                int food = _foodRepository.RefillFoodBag(foodId);
                return Ok(food);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("FamilyFood/{familyId}")]
        public IActionResult GetFamilyFood(Guid familyId)
        {
            try
            {
                return Ok(_foodRepository.GetFoodsFromFamily(familyId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("UploadImage")]
        public async Task<IActionResult> FoodImage(IFormFile file)
        {
            string filePath;
            string fileName;
            do
            {
                string randomName = Path.GetRandomFileName();
                fileName = randomName + "." + file.FileName.Split('.').Last();
                filePath = Path.Combine("Pictures","FoodPictures", fileName);
            } while (System.IO.File.Exists(filePath));

            using (var stream = System.IO.File.Create(filePath))
            {
                await file.CopyToAsync(stream);
            }

            return Ok(fileName);
        }
        [AllowAnonymous]
        [HttpGet("GetImage/{fileName}")]
        public async Task<IActionResult> GetImage(string fileName)
        {
            try
            {
                var filePath = Path.Combine("Pictures","FoodPictures", fileName);
                var image = System.IO.File.OpenRead(filePath);
                return File(image, $"image/jpeg");
            }
            catch
            {
                var image = System.IO.File.OpenRead("Pictures\\unknown.jpg");
                return File(image, "image/jpeg");
            }
        }
        [HttpPost("UpdateFoodBags/{foodId}/{amount}")]
        public async Task<IActionResult> AddFoodBags(Guid foodId, int amount)
        {
            try
            {
                return Ok(_foodRepository.AddFoodBags(foodId, amount));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("DeleteFood/{foodId}")]
        public IActionResult DeleteFood(Guid foodId)
        {
            try
            {
                return Ok(_foodRepository.DeleteFood(foodId));
            }
            catch(Exception ex)
            {
                return BadRequest($"could not delete food: {ex.Message}");
            }
        }
    }
}
