﻿using AutoMapper;
using ExampleWebApi.Api.Models;
using ExampleWebApi.Domain;
using ExampleWebApi.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExampleWebApi.Api.Controllers
{
    [Route("api/Animal")]
    public class AnimalController : ApiControllerBase
    {
        private readonly AnimalRepository _animalRepository;
        private readonly FamilyRepository _familyRepository;
        private readonly FoodRepository _foodRepository;
        public AnimalController(ExampleDbContext example, IMapper mapper)
        {
            _animalRepository = new AnimalRepository(example, mapper);
            _familyRepository = new FamilyRepository(example, mapper);
            _foodRepository = new(example, mapper);
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            List<Animal> animals = await _animalRepository.GetAllAnimals();
            return Ok(animals);
        }
        [HttpPost("Add")]
        public IActionResult Create([FromBody] AnimalModel animal)
        {
            if (string.IsNullOrWhiteSpace(animal.Name))
            {
                return BadRequest("animal name cannot be empty");
            }
            if (animal.MainFamilyId == null || animal.MainFamilyId == Guid.Empty)
            {
                return BadRequest("Family-Id is required");
            }
            Animal ani = new Animal
            {
                ImageUri = animal.ImageUri ?? "unknown.png",
                Name = animal.Name,
                MainFamily = _familyRepository.GetCompactFamily(animal.MainFamilyId ?? Guid.Empty),// die ?? is nodig omdat de compiler anders klaagt dat het niet nullable is
                FoodAmountPerDay = animal.FoodAmountPerDay,
                FoodTimesPerDay = animal.FoodTimesPerDay,
                Birthday = animal.Birthday,
                Breed = animal.Breed,
                Notes = animal.Notes,
                Food = _foodRepository.GetFullFood(animal.FoodId ?? Guid.Empty),
            };
            _animalRepository.CreateAnimalAsync(ani);
            return Ok(ani.Id);
        }
        [HttpPost("UploadImage")]
        public async Task<IActionResult> AnimalImage(IFormFile file)
        {
            string filePath;
            string fileName;
            do
            {
                string randomName = Path.GetRandomFileName();
                fileName = randomName + "." + file.FileName.Split('.').Last();
                filePath = Path.Combine("Pictures", fileName);
            } while (System.IO.File.Exists(filePath));

            using (var stream = System.IO.File.Create(filePath))
            {
                await file.CopyToAsync(stream);
            }

            return Ok(fileName);
        }
        [AllowAnonymous]
        [HttpGet("GetImage/{fileName}")]
        public async Task<IActionResult> GetImage(string fileName)
        {
            try
            {
                var filePath = Path.Combine("Pictures", fileName);
                var image = System.IO.File.OpenRead(filePath);
                return File(image, $"image/jpeg");
            }
            catch
            {
                var image = System.IO.File.OpenRead("Pictures\\unknown.jpg");
                return File(image, "image/jpeg");
            }
        }
        [HttpGet("GetAnimals/{familyId}")]
        public IActionResult GetAnimals(Guid familyId)
        {
            try
            {
                return Ok(_animalRepository.GetAnimalsFromFamily(familyId));
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("FeedAnimal/{animalId}")]
        public IActionResult FeedAnimal(Guid animalId)
        {
            try
            {
                int currentCapacity = _animalRepository.FeedAnimal(animalId);
                if (currentCapacity == -1)
                {
                    return BadRequest("Animal not found");
                }
                else if (currentCapacity == 0)
                {
                    return Ok("Food bag is empty");
                }
                else if (currentCapacity < (currentCapacity * 0.1))
                {
                    return Ok("Food bag is almost empty");
                }

                return Ok(currentCapacity);
            }
            catch
            {
                throw;
            }
        }
        [HttpDelete("RemoveAnimal/{animalId}")]
        public async Task<IActionResult> RemoveAnimal(Guid animalId)
        {
            try
            {
                await _animalRepository.RemoveAnimal(animalId);
                return Ok("animal removed.");
            }
            catch
            {
                return BadRequest("something went wrong");
            }
        }
        [HttpPut("ChangeAnimal")]
        public async Task<IActionResult> ChangeAnimal([FromBody] AnimalModel animal)
        {
            try
            {
                await _animalRepository.ChangeAnimalInfo(animal);
                return Ok("animal changed");
            }
            catch
            {
                return BadRequest("something went wrong");
            }
        }
    }
}
