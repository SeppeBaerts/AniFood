﻿using AutoMapper;
using ExampleWebApi.Domain;

namespace ExampleWebApi.Api.Models
{
    public class FamilyModel
    {
        public string Name { get; set; }
        public string? ImageUri { get; set; }
    }
    
}
