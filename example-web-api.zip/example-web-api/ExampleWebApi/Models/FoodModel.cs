﻿using AutoMapper;
using ExampleWebApi.Domain;

namespace ExampleWebApi.Api.Models
{
    /// <summary>
    /// This will return the info of the Object.
    /// </summary>
    public class FoodModel
    {
        public string Name { get; set; }
        public string? ImageUri { get; set; }
        public Guid ParentFamily { get; set; }
        public int Capacity { get; set; }
        /// <summary>
        /// This will default to the capacity if not specified
        /// </summary>
        public int? CurrentCapacity { get; set; }
        public class MappingProfile : Profile
        {
            public MappingProfile()
            {
                CreateMap<Food, FoodModel>();
            }
        } 
    }
}
